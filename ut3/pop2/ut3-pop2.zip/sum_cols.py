# ****************
# SUMANDO COLUMNAS
# ****************
from pathlib import Path


def run(data_path: Path) -> tuple:
    sum_array = []
    num_col = 0
    counter = 0
    i = 0
    with open(data_path) as f:
        for line in f:
            values = line.strip().split()
            for index, value in enumerate(values):
                if index == i:
                    num_col += int(value)
                    print((num_col))
                else:
                    sum_array.append(int(value))

    # csum = tuple(sum_array)

    # return csum


if __name__ == "__main__":
    run("data/sum_cols/data1.txt")
